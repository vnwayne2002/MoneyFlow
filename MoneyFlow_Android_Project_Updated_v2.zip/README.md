# Money Flow Android APK project

This is a WebView-wrapped Android app using the bundled Money Flow HTML app. It keeps data in WebView local storage and works offline.

## Build APK using GitHub Actions
1. Create a GitHub repository and upload all files in this folder.
2. Open the repository's **Actions** tab.
3. Choose **Build Money Flow APK** and press **Run workflow** (or push to `main`).
4. Wait for the workflow to finish.
5. Open the successful workflow run, scroll to **Artifacts**, and download `MoneyFlow-debug-apk`.
6. Extract the ZIP, then install `app-debug.apk` on Android. If prompted, allow installing unknown apps for the file manager/browser.

## Build locally
Install Android Studio, open this project, then run `gradle assembleDebug` from the project root. APK output: `app/build/outputs/apk/debug/app-debug.apk`.

This is a debug-signed APK for personal use. It is not Play Store-ready.
